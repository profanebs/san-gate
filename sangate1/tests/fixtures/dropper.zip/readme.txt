Just run setup.exe to finish.
